repo: freshstart17173-sketch/eski
branch: main

## Last sync
date: 2026-08-04T00:00:00Z

### Updated in this project
- Added a pastel-pink accent across the system marking the human layer; reworked dark mode to true charcoal.
- Split the studio into three role-locked mockups (author / composer / voiceover) with forced labeled slots, nested-one-shot timing, per-page preview, and streamlined status colors.
- Reworked the reader "mix" (VA-per-character + score, vouched cast, one-click voice-this-character, previews, pfps, kudos/follow) and wired real cover art.
- Authored eski brand guide.dc.html documenting every UI/UX decision with justifications.

## Screen map
| Project screen | Built from repo files |
|---|---|
| eski home.dc.html | index.html, tokens.css, eski-brand skill |
| eski reader.dc.html | read.html, tokens.css, eski-brand skill |
| eski studio author.dc.html | studio.html, tokens.css, eski-brand skill |
| eski studio composer.dc.html | studio.html, tokens.css, eski-brand skill |
| eski studio voiceover.dc.html | studio.html, tokens.css, eski-brand skill |
| eski profile.dc.html | tokens.css, eski-brand skill |
| eski brand guide.dc.html | eski-brand skill (new) |

## Notes
- Same sage color scheme and Gnomon display font kept per brief.
- Redesign brief: friendlier UX, clearer primary actions, progressive disclosure. Fixed brand tiers (sage ramp, Gnomon, wordmark pairing, no em dashes) preserved.
